@extends('layouts.master')

@section('content')
    <h1>Welcome, Superadmin!</h1>
    <p>This is the Superadmin dashboard.</p>
@endsection
